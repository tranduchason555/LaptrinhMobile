package com.example.doanthietbididong;

public class ModelClass {
    String NotiName, NotiNum;
    int img;

    public String getNotiName() {
        return NotiName;
    }

    public void setNotiName(String notiName) {
        NotiName = notiName;
    }

    public String getNotiNum() {
        return NotiNum;
    }

    public void setNotiNum(String notiNum) {
        NotiNum = notiNum;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }
}
