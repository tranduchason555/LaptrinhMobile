package com.example.doanthietbididong;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ThongBaoMoi1Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thong_bao_moi1);
    }
}