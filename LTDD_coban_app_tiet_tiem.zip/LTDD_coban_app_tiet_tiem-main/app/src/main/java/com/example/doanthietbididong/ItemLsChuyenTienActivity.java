package com.example.doanthietbididong;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ItemLsChuyenTienActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_ls_chuyen_tien);
    }
}