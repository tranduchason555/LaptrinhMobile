package com.example.doanthietbididong;

import android.widget.EditText;
import android.widget.TextView;

public class Money {
    String naptien;
    String tien;
    String chuyentien;
    String soluongtktk;
    String ngaymoso;
    String ngayketso;
    String email;
    String nhapsothe;
    String hotenchuthe;
    String id;
    String ngaythangnam;
    String sodienthoai;
    String tenTkTk;
    String kyhan;
    String laisuatnam;
    String tonglaisuat;

    public Money(){}
    public Money(String naptien, String tien, String chuyentien, String soluongtktk, String ngaymoso, String ngayketso, String email, String nhapsothe, String hotenchuthe, String id, String ngaythangnam, String sodienthoai, String tenTkTk, String kyhan, String laisuatnam, String tonglaisuat) {
        this.naptien = naptien;
        this.tien = tien;
        this.chuyentien = chuyentien;
        this.soluongtktk = soluongtktk;
        this.ngaymoso = ngaymoso;
        this.ngayketso = ngayketso;
        this.email = email;
        this.nhapsothe = nhapsothe;
        this.hotenchuthe = hotenchuthe;
        this.id = id;
        this.ngaythangnam = ngaythangnam;
        this.sodienthoai = sodienthoai;
        this.tenTkTk = tenTkTk;
        this.kyhan = kyhan;
        this.laisuatnam = laisuatnam;
        this.tonglaisuat = tonglaisuat;
    }

    public String getNaptien() {
        return naptien;
    }

    public void setNaptien(String naptien) {
        this.naptien = naptien;
    }

    public String getTien() {
        return tien;
    }

    public void setTien(String tien) {
        this.tien = tien;
    }

    public String getChuyentien() {
        return chuyentien;
    }

    public void setChuyentien(String chuyentien) {
        this.chuyentien = chuyentien;
    }

    public String getSoluongtktk() {
        return soluongtktk;
    }

    public void setSoluongtktk(String soluongtktk) {
        this.soluongtktk = soluongtktk;
    }

    public String getNgaymoso() {
        return ngaymoso;
    }

    public void setNgaymoso(String ngaymoso) {
        this.ngaymoso = ngaymoso;
    }

    public String getNgayketso() {
        return ngayketso;
    }

    public void setNgayketso(String ngayketso) {
        this.ngayketso = ngayketso;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNhapsothe() {
        return nhapsothe;
    }

    public void setNhapsothe(String nhapsothe) {
        this.nhapsothe = nhapsothe;
    }

    public String getHotenchuthe() {
        return hotenchuthe;
    }

    public void setHotenchuthe(String hotenchuthe) {
        this.hotenchuthe = hotenchuthe;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNgaythangnam() {
        return ngaythangnam;
    }

    public void setNgaythangnam(String ngaythangnam) {
        this.ngaythangnam = ngaythangnam;
    }

    public String getSodienthoai() {
        return sodienthoai;
    }

    public void setSodienthoai(String sodienthoai) {
        this.sodienthoai = sodienthoai;
    }

    public String getTenTkTk() {
        return tenTkTk;
    }

    public void setTenTkTk(String tenTkTk) {
        this.tenTkTk = tenTkTk;
    }

    public String getKyhan() {
        return kyhan;
    }

    public void setKyhan(String kyhan) {
        this.kyhan = kyhan;
    }

    public String getLaisuatnam() {
        return laisuatnam;
    }

    public void setLaisuatnam(String laisuatnam) {
        this.laisuatnam = laisuatnam;
    }

    public String getTonglaisuat() {
        return tonglaisuat;
    }

    public void setTonglaisuat(String tonglaisuat) {
        this.tonglaisuat = tonglaisuat;
    }


}
